<?php session_start();?>
<html>
<head><title>SRM UNIVERSITY PORTAL</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>


<body>
<?php
 $server="127.0.0.1";
 $username="root";
 $password="";
 $dbname="student";
 $usr_id=$_SESSION['usr_id'];
 $conn= mysqli_connect($server, $username, $password, $dbname);
 $sql="select * from student_details where student_id='$usr_id'";
 $result= mysqli_query($conn,$sql);
 if(isset($result)){
     while($row=mysqli_fetch_array($result)){
?>
    <section class="header">
            
        <a href="myweb.html"><image src="images/srm.png"></a>
            <div class="table-box">
                <div class="table-row table-head">
                    <div class="table-cell first-cell">
                        <p>STUDENT PORTAL</p>
                    </div>
                    <div class="table-cell">
                       
                    </div>
                    
                </div>
        
        
                <div class="table-row">
                    <div class="table-cell first-cell">
                        <p style="color: white;">Student Name</p>
                    </div>
                    <div class="table-cell">
                        <p style="color: white;"><?php echo $row['name'];?></p>
                    </div>
                       
                </div>
        
        
                <div class="table-row">
                    <div class="table-cell first-cell">
                        <p style="color: white;">Register ID</p>
                    </div>
                    <div class="table-cell">
                        <p style="color: white;"><?php echo $row['student_id'];?></p>
                    </div>
                    
                </div>
        
                <div class="table-row">
                    <div class="table-cell first-cell">
                        <p style="color: white;">Academic Year</p>
                    </div>
                    <div class="table-cell">
                        <p style="color: white;">2018-2022</p>
                    </div>
                    
                </div>
        
                <div class="table-row">
                    <div class="table-cell first-cell">
                        <p style="color: white;">Semester</p>
                    </div>
                    <div class="table-cell">
                        <p style="color: white;">2nd semester</p>
                    </div>
                    
                </div>
        
                <div class="table-row">
                    <div class="table-cell first-cell">
                        <p style="color: white;">D.O.B</p>
                    </div>
                    <div class="table-cell">
                        <p style="color: white;"><?php echo $row['dob'];?></p>
                    </div>
                    
                </div>
        
        
                <div class="table-row">
                    <div class="table-cell first-cell">
                        <p style="color: white;">Branch</p>
                    </div>
                    <div class="table-cell">
                        <p style="color: white;"><?php echo $row['branch'];?></p>
                    </div>
                    
                </div>
                <div class="table-row">
                    <div class="table-cell first-cell">
                        <p style="color: white;">1st Year CGPA</p>
                    </div>
                    <div class="table-cell">
                        <p style="color: white;">8.9cgpa</p>
                    </div>
                    
                </div>
                <div class="table-row">
                    <div class="table-cell first-cell">
                        <p style="color: white;">2nd Year SGPA</p>
                    </div>
                    <div class="table-cell">
                        <p style="color: white;">9.0cgpa</p>
                    </div>
                    
                </div>
                
        
                
        </div>  
    
</section>
<?php }
       } ?>
</body>
</html>