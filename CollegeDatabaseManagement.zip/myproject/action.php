<?php 
session_start();
$server="127.0.0.1";
$username="root";
$password="";
$dbname="student";
$conn= mysqli_connect($server, $username, $password, $dbname);
if(isset($_POST['create'])){
    if(!empty($_POST['name']) && !empty($_POST['pass']) && !empty($_POST['mail']) && !empty($_POST['dob']) && !empty($_POST['branch'])){
        $name=$_POST['name'];
        $pass=$_POST['pass'];
        $mail=$_POST['mail'];
        $dob=$_POST['dob'];
        $branch=$_POST['branch'];
        $query="insert into student_details(name,password,email,dob,branch) values('$name','$pass','$mail' ,'$dob' ,'$branch')";
        $run= mysqli_query($conn,$query) or die(mysqli_error($conn)) ;
        if($run){
            echo"<script>window.location='login.html';</script>";
        }
        else{
            echo"fail";
        }
    } 
}
if(isset($_POST['login'])){
    if(!empty($_POST['name']) && !empty($_POST['pass'])){
        $name=$_POST['name'];
        $pass=$_POST['pass']; 
        $sql="select * from student_details where name='$name' AND password='$pass'";
	    $result= mysqli_query($conn,$sql);
	    $check=mysqli_fetch_array($result);
        if($check['name']==$name && $check['password']==$pass){
            $_SESSION['usr_id']=$check['student_id'];
            echo"<script>window.location='portal.php';</script>";
        }
        else{
              echo"enter a valid password";
        }
    }
}
?>